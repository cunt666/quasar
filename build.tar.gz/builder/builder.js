import fs from 'fs';
import ejs from 'ejs';
import path from 'path'
import Module from "module";
import process from "process";
import { exec } from "child_process";

//PROTO
import settings from "./settings.js";
import ConnectorModel from './_connector.js'
  //MONGO
  import mongoModel from './tmp/mongo/mongoModel.js'
  import mongoRouter from './tmp/mongo/mongoRouter.js'
  import mongoServices from './tmp/mongo/mongoServices.js'
  import mongoController from './tmp/mongo/mongoController.js'
  //API
  import apiServer from './tmp/api/server.js'
  import apiRouter from './tmp/api/router.js'
  import apiRoute from './tmp/api/apiRoute.js'
  import apiAuth from './tmp/api/apiAuthExtension.js'
  import apiAuthController from './tmp/api/apiAuthExtensionController.js'
  import apiAuthMiddlewear from './tmp/api/apiAuthExtensionMiddlewear.js'
  //FRONTEND
  import frontStore from './tmp/front/store.js'
  import frontRouter from './tmp/front/router.js'
  import frontRoutes from './tmp/front/routes.js'
  import frontVuex from './tmp/front/vuex.js'
  import authVuex from './tmp/front/authVuex.js'

//CREATE OUTPUT APP DIR

//ENV OPTIONS
const JS_EXTENSIONS = new Set(['.js', '.mjs']);
const options = settings.options;
var baseURL = new URL('file://')
    baseURL.pathname = `${process.cwd()}/`
    baseURL.models = `${process.cwd()}/models`;
    baseURL.api = `../app/back/`
    baseURL.front = `../app/front/src/`

//MODELS ARRAY
let allModelsData = []


//IMPORT MODELS
const setModels = (modelPath)=>{
  return new Promise((resolve)=>{
    fs.readdir(modelPath, (e,f) => {
         f.forEach(mPath=>{
           if(!JS_EXTENSIONS.has(path.extname(mPath))) return
           impordModel(`${modelPath}/${mPath}`)
           .then(res=>{
             allModelsData.push({...res,name:path.basename(mPath,path.extname(mPath))})
             if(f.length==allModelsData.length) resolve()
           })
       })
    })
  });
}
const impordModel = (model) => {
  return new Promise(resolve=> import(model).then((modelData)=>resolve(modelData)) )
}


//INIT FILE BUILDER
const initFileBuilder = () => {
  //Change array to component
  var frontProtoNames = []
  var frontProtoModels = []
  var protoNames = []
  var protoModels = []
  var isPagesModels = []
  var isPagesNames = []
      isPagesNames.push('Dashboard')
  allModelsData.push({default:{},name:'Auth'})
  var proto = allModelsData.map(el=> {
    var formatedName = el.name
    if(el.name.includes('.page')){
      var formatedName = el.name.replace('.page','')
      el.default.isPage = true
      isPagesModels.push({default:el.default})
      isPagesNames.push(formatedName)
    }
    if(el.name!='Auth'){
      protoNames.push(formatedName)
      protoModels.push(el.default)
    }
    frontProtoNames.push(formatedName)
    frontProtoModels.push(el.default)
    return createConnectorPrototype(el.default,formatedName)
  })
  //Init app
  var appData = {}
      if(settings.options.auth) {
         appData.auth = ejs.render(apiAuth)
         appData.authController = ejs.render(apiAuthController)
         appData.authMiddlewear = ejs.render(apiAuthMiddlewear)
      }
      appData.server = ejs.render(apiServer)
      appData.router = ejs.render(apiRouter,{DATA:protoNames})

      //ADD API
      createFiles(baseURL.api+'middleweare/','js',appData.authMiddlewear,'authMiddlewear')
      createFiles(baseURL.api+'controllers/','js',appData.authController,'authController')
      createFiles(baseURL.api+'routes/','js',appData.auth,'authRouter')
      createFiles(baseURL.api,'js',appData.server,'index')
      createFiles(baseURL.api+'routes/','js',appData.router,'router')
      //COPY SETTINGS AND DEPENDENCIES
      fs.copyFile("./tmp/procfile.json", '../'+"procfile.json",(e)=>{});
      fs.copyFile("./settings.js", baseURL.api+"settings.js",(e)=>{});
      fs.copyFile("tmp/api/package.json", baseURL.api+"package.json",(e)=>{});
      //GENERATE MODELS
      proto.forEach(el=>{
        if(el.name=='Auth'){
          return createFiles(baseURL.front+'store/','js',el.front.vuex,el.name+'.module')
        }
        createFiles(baseURL.api+'models/','js',el.mongo.model,el.name)
        createFiles(baseURL.api+'controllers/','js',el.mongo.controller,el.name+'Controller')
        createFiles(baseURL.api+'services/','js',el.mongo.services,el.name+'Service')
        createFiles(baseURL.api+'routes/','js',el.mongo.router,el.name)
        //frontStore
        createFiles(baseURL.front+'store/','js',el.front.vuex,el.name+'.module')
      })
      //FRONT BUILDER
      fs.copyFile("./settings.js", baseURL.front+"settings.js",(e)=>{});
      fs.copyFile("./tmp/front/basic/Posts.vue", baseURL.front+"pages/Posts.vue",(e)=>{});
      fs.copyFile("./tmp/front/basic/Index.vue", baseURL.front+"pages/Index.vue",(e)=>{});
      fs.copyFile("./tmp/front/basic/Dashboard.vue", baseURL.front+"pages/Dashboard.vue",(e)=>{});
      let front = {}
          front.store = ejs.render(frontStore, {NAME: frontProtoNames,DATA:frontProtoNames})
          front.router = ejs.render(frontRouter, {NAME: isPagesNames,DATA:isPagesModels})
          front.routes = ejs.render(frontRoutes, {NAME: isPagesNames,DATA:isPagesModels})
      createFiles(baseURL.front+'store/','js',front.store,'index')
      createFiles(baseURL.front+'router/','js',front.router,'index')
      createFiles(baseURL.front+'router/','js',front.routes,'routes')
}
const createConnectorPrototype = (data,name) => {
    //MONGO
    let mongo = {}
        mongo.model = ejs.render(mongoModel, {DATA: data, NAME: name})
        mongo.controller = ejs.render(mongoController, {NAME: name})
        mongo.services = ejs.render(mongoServices, {NAME: name})
        mongo.router = ejs.render(mongoRouter, {NAME: name})

    //API
    let api = {}
        api.route = ejs.render(apiRoute, {NAME: name,DATA:data})

    //FRONTEND
    let front = {}
    if(name=='Auth'){
      front.vuex = ejs.render(authVuex, {NAME: name,DATA:data})
    }else{
      front.vuex = ejs.render(frontVuex, {NAME: name,DATA:data})
    }
    return new ConnectorModel(data,name,mongo,api,front);
}
const createFiles = (endPoint,ext,data,name,createFolder) =>{
    if(!fs.existsSync(`${endPoint}`)) fs.mkdirSync(`${endPoint}`);
    if(createFolder) fs.writeFileSync(`${endPoint}/${name}.${ext}`, data);
    else fs.writeFileSync(`${endPoint}${name}.${ext}`, data);
}


//INIT
setModels(baseURL.models)
.then(res=>{
  initFileBuilder()
})
