export default {
    value: { type: "String", unique: "true", default: 'User'}
}
