export default {
    value: { type: "Array", unique: "true", default: 'Posts'}
}
