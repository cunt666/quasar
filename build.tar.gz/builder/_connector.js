export default class ConnectorModel{
  constructor(data,name,mongo,api,front){
    this.default = data
    this.name = name
    this.mongo = mongo
    this.api = api
    this.front = front
  }
}
