export default `
import Router from 'express';
<% for( key in DATA ){ %> import <%- DATA[key] %> from './<%- DATA[key] %>.js'; <% }%>
const router = new Router();

      <% for( key in DATA ){ %> router.use(<%= DATA[key] %>); <% }  %>
export default router;
`
