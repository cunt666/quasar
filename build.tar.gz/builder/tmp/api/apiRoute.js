export default `
import Router from 'express';
import <%= NAME %>Controller from '../controllers/<%= NAME %>Controller.js';

const router = new Router();

router.post('/<%= NAME.toLowerCase() %>', <%= NAME %>Controller.create);
router.get('/<%= NAME.toLowerCase() %>', <%= NAME %>Controller.getAll);
router.get('/<%= NAME.toLowerCase() %>/:id', <%= NAME %>Controller.getSingle);
router.put('/<%= NAME.toLowerCase() %>/', <%= NAME %>Controller.update);
router.delete('/<%= NAME.toLowerCase() %>/:id', <%= NAME %>Controller.delete);

export default router;
`
