export default
`import mongoose from 'mongoose';

const <%= NAME %> = new mongoose.Schema({
    <% for( key in DATA){ %>
      <%- key %> : {
        <% for( key2 in DATA[key] ) { %>
          <%- key2 %> : <%- key2=='type'||key2=='unique'||key2=='required'? DATA[key][key2] : "'"+DATA[key][key2].toString()+"'" %>,
        <% } %>
      },
    <% } %>
})

export default mongoose.model('<%= NAME %>', <%= NAME %>);
`
