export default
`
import <%= NAME %> from '../models/<%= NAME %>.js';

class <%= NAME %>Service {

  async create(item){
      const response = await <%= NAME %>.create(item);
      return response;
  }

  async getAll(){
      const response = await <%= NAME %>.find();
      return response;
  }

  async getSingle(id){
      const response = await <%= NAME %>.findById(id);
      return response;
  }

  async update(item){
      const response = await <%= NAME %>.findByIdAndUpdate(item._id, item, {new: true} );
      return response;
  }

  async delete(id){
      const response = await <%= NAME %>.findByIdAndDelete(id);
      return response;
  }

}

export default new <%= NAME %>Service();
`
