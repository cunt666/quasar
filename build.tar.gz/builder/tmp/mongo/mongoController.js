export default `
import <%= NAME %> from '../models/<%= NAME %>.js';
import <%= NAME %>Service from '../services/<%= NAME %>Service.js';

class <%= NAME %>Controller {

  async create(req,res){
    try{
      const response = await <%= NAME %>Service.create(req.body);
      res.json(response)
    } catch(e){
      res.status(500).json(e.message);
    }
  }

  async getAll(req,res){
    try{
      const response = await <%= NAME %>Service.getAll();
      return res.json(response);
    } catch(e){
      res.status(500).json(e.message);
    }
  }

  async getSingle(req,res){
    try{
      const response = await <%= NAME %>Service.getSingle(req.query.id);
      return res.json(response);
    } catch(e){
      res.status(500).json(e.message);
    }
  }

  async update(req,res){
    try{
      const response = await <%= NAME %>Service.update(req.body);
      return res.json(response);
    } catch(e){
      res.status(500).json(e.message);
    }
  }

  async delete(req,res){
    try{
      const response = await <%= NAME %>Service.delete(req.query.id);
      return res.json(response);
    } catch(e){
      res.status(500).json(e.message);
    }
  }

}

export default new <%= NAME %>Controller();
`
