export default `
  export default {
     namespaced: true,
     state: {
       <%- NAME %>: [{<% for( key in DATA){ %> <%- key %> : '', <% } %>}]
     },
     mutations: {
       <%- NAME %>_SET (state, payload) {
         state.<%- NAME %> = payload
       }
     },
     getters: {
       <%- NAME %>_GETTER: function (state) {
         return state.<%- NAME %>
       }
     },
     actions: {
       <%- NAME %>_REGISTRATION(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.get('/<%- NAME.toLowerCase() %>/registration', payload)
            .then(res=> {
              context.commit('<%- NAME %>_SET', res.data)
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_GET_ALL(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.get('/<%- NAME.toLowerCase() %>/users')
            .then(res=> {
              context.commit('<%- NAME %>_SET', res.data)
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_LOGIN(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.post('/<%- NAME.toLowerCase() %>/login', payload)
            .then(res=> {
              context.commit('<%- NAME %>_SET', res.data)
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_UPDATE(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.update('/<%- NAME.toLowerCase() %>/update', payload)
            .then(res=> {
              context.commit('<%- NAME %>_SET', res.data)
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_DELETE(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.delete('/<%- NAME.toLowerCase() %>/delete',{params:{ id: payload._id } })
            .then(res=> {
              context.commit('<%- NAME %>_SET', res.data)
               resolve(res.data)
            }).catch(err=>reject(err))
          })

       }
     }
  }`
