export default `
  export default {
     namespaced: true,
     state: {
       <%- NAME %>: [{<% for( key in DATA){ %> <%- key %> : '', <% } %>}]
     },
     mutations: {
       <%- NAME %>_SET (state, payload) {
         state.<%- NAME %> = payload
       }
     },
     getters: {
       <%- NAME %>_GETTER: function (state) {
         return state.<%- NAME %>
       }
     },
     actions: {
       <%- NAME %>_GET_SINGLE(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.get('/api/<%- NAME.toLowerCase() %>', payload)
            .then(res=> {
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_GET_ALL(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.get('/api/<%- NAME.toLowerCase() %>')
            .then(res=> {
              context.commit('<%- NAME %>_SET', res.data)
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_SET(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.post('/api/<%- NAME.toLowerCase() %>', payload)
            .then(res=> {
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_UPDATE(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.put('/api/<%- NAME.toLowerCase() %>',payload)
            .then(res=> {
               resolve(res.data)
            }).catch(err=>reject(err))
          })
       },
       <%- NAME %>_DELETE(context, payload) {
         return new Promise((resolve,reject)=>{
           this.$axios.delete('/api/<%- NAME.toLowerCase() %>/<%- NAME.toLowerCase() %>',{params:{ id: payload._id } })
            .then(res=> {
               resolve(res.data)
            }).catch(err=>reject(err))
          })

       }
     }
  }`
