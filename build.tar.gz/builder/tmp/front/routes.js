export default `
const routes = [
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: '', component: () => import('pages/Index.vue') },
      <% for( key in NAME ) {%> { path: '/'+'<%- NAME[key] %>', component: () => import('pages/'+'<%- NAME[key] %>'+'.vue') }, <% } %>
    ]
  },

  {
    path: '/:catchAll(.*)*',
    component: () => import('pages/Error404.vue')
  }
]

export default routes
`
