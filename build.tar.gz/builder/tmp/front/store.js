export default `
    import { store } from 'quasar/wrappers'
    import { createStore } from 'vuex'
    import axios from 'axios'
    import settings from '../settings.js'
    /*MODULES*/
    <% for( key in NAME ){ %> import <%- NAME[key] %> from './<%- NAME[key] %>.module.js'; <% }%>

    export default store(function () {
      const Store = createStore({
        modules: {
          <% for( key in NAME){ %> <%- NAME[key] %> : <%- NAME[key] %>, <% } %>
        },
        strict: process.env.DEBUGGING
      })
      axios.defaults.baseURL = "http://"+settings.api.HOST+":"+settings.api.PORT
      axios.defaults.withCredentials = true;
      Store.$axios = axios
      return Store
    })
`
